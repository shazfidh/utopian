<html>
<body>
//NEXT SLIDE   
    function nextSlide() {
        var $active = $('.feature-banner slide.active');

        if ( $active.length == 0 ) $active = $('.feature-banner slide:last');

        var $next =  $active.next().is("slide") ? $active.next()
            : $('.feature-banner slide:first');

        $active.addClass('last-active');

        $next.css({opacity: 0.0})
            .addClass('active')
            .animate({opacity: 1.0}, 200, function() {
                $active.removeClass('active last-active');
            });
    }

    ///$(function() {
   ///     setInterval( "slideSwitch()", 5000 );
    ///});
$( "#nextslide" ).click(function() {
  nextSlide();
});


//PREVIOUS SLIDE
    function prevSlide() {
        var $active = $('.feature-banner slide.active');

        if ( $active.length == 0 ) $active = $('.feature-banner slide:first');

        var $next =  $active.prev().is("slide") ? $active.prev()
            : $('.feature-banner slide:last');

        $active.addClass('last-active');

        $next.css({opacity: 0.0})
            .addClass('active')
            .animate({opacity: 1.0}, 200, function() {
                $active.removeClass('active last-active');
            });
    }

$( "#previousslide" ).click(function() {
  prevSlide();
});


</body>
</html>